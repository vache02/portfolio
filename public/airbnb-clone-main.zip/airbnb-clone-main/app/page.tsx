export default function Home() {
  return <div className="text-rose-500">Hello</div>;
}
